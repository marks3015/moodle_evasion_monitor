<?php
require_once('../../config.php');
require_login();
require_capability('local/monitorevasao:view', context_system::instance());

// Configura a página
$PAGE->set_url(new moodle_url('/local/monitorevasao/logs.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Logs do Monitor de Evasão');
$PAGE->set_heading('Logs do Monitor de Evasão');

echo $OUTPUT->header();

// Função para ler os últimos logs
function get_debug_logs($lines = 100) {
    global $CFG;
    
    $logfile = $CFG->dataroot . '/debug.log';
    $logs = [];
    
    if (file_exists($logfile)) {
        $logs = array_slice(file($logfile), -$lines);
    }
    
    return $logs;
}

// Botão para limpar logs
if (isset($_POST['clear_logs'])) {
    global $CFG;
    $logfile = $CFG->dataroot . '/debug.log';
    if (file_exists($logfile)) {
        file_put_contents($logfile, '');
        echo '<div class="alert alert-success">Logs limpos com sucesso!</div>';
    }
}

// Interface
?>
<div class="card mb-3">
    <div class="card-body">
        <h3>Logs do Sistema</h3>
        <p>Últimos registros de debug do plugin Monitor de Evasão.</p>
        
        <form method="post" class="mb-3">
            <button type="submit" name="clear_logs" class="btn btn-warning">
                <i class="fa fa-trash"></i> Limpar Logs
            </button>
        </form>
        
        <div class="bg-light p-3" style="max-height: 500px; overflow-y: auto;">
            <pre><?php
            $logs = get_debug_logs();
            if (!empty($logs)) {
                foreach ($logs as $log) {
                    if (strpos($log, 'monitorevasao') !== false) {
                        echo htmlspecialchars($log);
                    }
                }
            } else {
                echo "Nenhum log encontrado.";
            }
            ?></pre>
        </div>
    </div>
</div>

<!-- Configurações atuais -->
<div class="card">
    <div class="card-body">
        <h3>Configurações do Sistema</h3>
        <pre><?php
        echo "SMTP Host: " . (!empty($CFG->smtphosts) ? $CFG->smtphosts : 'Não configurado') . "\n";
        echo "SMTP Secure: " . (!empty($CFG->smtpsecure) ? $CFG->smtpsecure : 'Não configurado') . "\n";
        echo "SMTP Auth: " . (!empty($CFG->smtpuser) ? 'Configurado' : 'Não configurado') . "\n";
        echo "No-reply: " . (!empty($CFG->noreplyaddress) ? $CFG->noreplyaddress : 'Não configurado') . "\n";
        echo "Debug: " . $CFG->debug . "\n";
        echo "Debug Display: " . $CFG->debugdisplay . "\n";
        ?></pre>
    </div>
</div>

<?php
echo $OUTPUT->footer(); 