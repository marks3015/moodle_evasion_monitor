# Changelog
Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

## [1.1.0] - 2025-03-01 (Versão 2025030100)
### Adicionado
- Sistema de envio de e-mails para usuários inativos
- Interface para envio de e-mails em lote
- Registro de e-mails enviados
- Novas permissões para gerenciamento de e-mails
- Templates personalizáveis para e-mails

### Alterado
- Atualização da versão para 2025030100
- Melhorias na interface do usuário
- Otimização do sistema de monitoramento

### Corrigido
- Correção na contagem de tempo de inatividade
- Melhorias na performance das consultas

## [1.0.0] - 2024-03-21
- Versão inicial do plugin 