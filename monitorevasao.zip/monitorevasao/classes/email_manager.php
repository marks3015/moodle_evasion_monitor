<?php
namespace local_monitorevasao;

defined('MOODLE_INTERNAL') || die();

/**
 * Gerenciador de e-mails para usuários inativos
 */
class email_manager {
    /**
     * Envia e-mails em lote
     * @return array Resultados do envio
     */
    public static function enviar_emails_lote() {
        global $DB, $CFG, $SITE;

        debugging('Iniciando envio em lote', DEBUG_DEVELOPER);

        // Obtém usuários inativos do observer
        $observer = new observer();
        $usuarios = $observer->verificar_ultimo_acesso();

        // Certifique-se de que a lista de usuários está correta
        if (empty($usuarios)) {
            debugging('Nenhum usuário inativo encontrado.', DEBUG_DEVELOPER);
            return [
                'total' => 0,
                'enviados' => 0,
                'falhas' => 0
            ];
        }

        debugging('Usuários inativos encontrados: ' . count($usuarios), DEBUG_DEVELOPER);

        $resultados = [
            'total' => count($usuarios),
            'enviados' => 0,
            'falhas' => 0
        ];

        // Envia e-mails apenas para usuários inativos
        foreach ($usuarios as $usuario) {
            debugging('Processando usuário: ' . $usuario->id, DEBUG_DEVELOPER);

            try {
                // Verifica último envio de e-mail
                $ultimo_envio = $DB->get_field_sql(
                    "SELECT MAX(timecreated) 
                     FROM {local_monitorevasao_emails} 
                     WHERE userid = ? AND status = 1",
                    [$usuario->id]
                );

                // Se existe envio nas últimas 24 horas, pula este usuário
                // 24 * 3600 = 1 dia
                if ($ultimo_envio && (time() - $ultimo_envio) < 300) {
                    debugging('E-mail já enviado nas últimas 24h para: ' . $usuario->id, DEBUG_DEVELOPER);
                    continue;
                }

                // Verifica se é administrador
                if (is_siteadmin($usuario->id)) {
                    debugging('Usuário é administrador, ignorando envio: ' . $usuario->id, DEBUG_DEVELOPER);
                    continue;
                }

                // Validações básicas
                if (empty($usuario->email)) {
                    debugging('ERRO: Usuário sem e-mail: ' . $usuario->id, DEBUG_DEVELOPER);
                    $resultados['falhas']++;
                    continue;
                }

                if (!validate_email($usuario->email)) {
                    debugging('ERRO: E-mail inválido: ' . $usuario->email, DEBUG_DEVELOPER);
                    $resultados['falhas']++;
                    continue;
                }

                // Prepara os dados para o e-mail
                $dados = [
                    'nome' => fullname($usuario),
                    'email' => $usuario->email,
                    'ultimo_acesso' => userdate($usuario->lastaccess),
                    'site_nome' => $SITE->fullname,
                    'login_url' => $CFG->wwwroot . '/login/index.php'
                ];

                // Personaliza o corpo do e-mail com base na evasão
                $dias_evasao = (time() - $usuario->lastaccess) / (60 * 60 * 24);
                if ($dias_evasao >= 7) {
                    $mensagem = self::get_corpo_email_7_dias($dados);
                } else {
                    $mensagem = self::get_corpo_email_1_dia($dados);
                }

                debugging('Dados preparados: ' . print_r($dados, true), DEBUG_DEVELOPER);

                // Configura o e-mail
                $assunto = get_string('email_subject', 'local_monitorevasao', $SITE->fullname);

                // Configura o remetente
                $from_user = \core_user::get_noreply_user();

                // Envia o e-mail
                $resultado = email_to_user(
                    $usuario,
                    $from_user,
                    $assunto,
                    strip_tags($mensagem),
                    $mensagem
                );

                // Registra o resultado
                if ($resultado) {
                    debugging('E-mail enviado com sucesso: ' . $usuario->email, DEBUG_DEVELOPER);
                    self::registrar_envio($usuario->id, 1, $usuario->email);
                    $resultados['enviados']++;
                } else {
                    debugging('ERRO: Falha no envio do e-mail: ' . $usuario->email, DEBUG_DEVELOPER);
                    self::registrar_envio($usuario->id, 0, $usuario->email);
                    $resultados['falhas']++;
                }

            } catch (\Exception $e) {
                debugging('ERRO: Exception no envio: ' . $e->getMessage(), DEBUG_DEVELOPER);
                self::registrar_envio($usuario->id, 0, $usuario->email);
                $resultados['falhas']++;
            }
        }

        debugging('Processo finalizado. Resultados: ' . print_r($resultados, true), DEBUG_DEVELOPER);

        return $resultados;
    }

    /**
     * Registra envio no banco de dados
     * @param int $userid ID do usuário
     * @param int $status Status do envio (0=falha, 1=sucesso)
     */
    private static function registrar_envio($userid, $status, $email) {
        global $DB;

        $registro = new \stdClass();
        $registro->userid = $userid;
        $registro->email = $email;
        $registro->timecreated = time();
        $registro->status = $status;

        return $DB->insert_record('local_monitorevasao_emails', $registro);
    }

    /**
     * Gera o corpo do e-mail para 1 dia de evasão
     * @param array $dados Dados para o template
     * @return string HTML do e-mail
     */
    private static function get_corpo_email_1_dia($dados) {
        // Obtém o corpo do e-mail do arquivo de idioma
        $html = get_string('email_body_1_dia', 'local_monitorevasao');
        
        // Substitui as variáveis no template
        foreach ($dados as $chave => $valor) {
            $html = str_replace('{' . $chave . '}', $valor, $html);
        }
        
        return $html;
    }

    /**
     * Gera o corpo do e-mail para 7 dias ou mais de evasão
     * @param array $dados Dados para o template
     * @return string HTML do e-mail
     */
    private static function get_corpo_email_7_dias($dados) {
        // Obtém o corpo do e-mail do arquivo de idioma
        $html = get_string('email_body_7_dias', 'local_monitorevasao');
        
        // Substitui as variáveis no template
        foreach ($dados as $chave => $valor) {
            $html = str_replace('{' . $chave . '}', $valor, $html);
        }
        
        return $html;
    }
}