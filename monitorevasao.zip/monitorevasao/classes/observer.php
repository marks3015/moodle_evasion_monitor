<?php
namespace local_monitorevasao;

class observer {
    public static function verificar_ultimo_acesso($segundos = 3600) {
        global $DB;
        
        // A consulta SQL já inclui o campo email
        $sql = "SELECT u.id, u.firstname, u.lastname, u.lastaccess, u.email
                FROM {user} u
                WHERE u.deleted = 0 
                AND u.suspended = 0
                AND u.lastaccess < :tempolimite
                AND u.lastaccess > 0
                AND u.id > 1
                AND u.id NOT IN (
                    SELECT userid 
                    FROM {role_assignments} ra
                    JOIN {role} r ON r.id = ra.roleid
                    WHERE r.archetype = 'admin'
                )";
                
        return $DB->get_records_sql($sql, ['tempolimite' => time() - $segundos]);
    }
} 