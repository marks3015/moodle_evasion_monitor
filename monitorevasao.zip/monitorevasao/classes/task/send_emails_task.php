<?php
namespace local_monitorevasao\task;

class send_emails_task extends \core\task\scheduled_task {
    public function get_name() {
        return get_string('task_send_emails', 'local_monitorevasao');
    }

    public function execute() {
        \local_monitorevasao\email_manager::enviar_emails_lote();
    }
} 