<?php
require_once('../../config.php');
require_login();

// Ativa debug
debugging('Iniciando processo de envio de e-mails', DEBUG_DEVELOPER);

// Headers
header('Content-Type: application/json');

try {
    // Verifica permissões
    require_capability('local/monitorevasao:view', context_system::instance());
    
    // Obtém parâmetros
    $raw_data = file_get_contents('php://input');
    $data = json_decode($raw_data);
    $segundos = isset($data->segundos) ? (int)$data->segundos : 10;
    
    debugging('Parâmetros recebidos: ' . print_r($data, true), DEBUG_DEVELOPER);
    
    // Instancia o gerenciador de e-mails
    $email_manager = new \local_monitorevasao\email_manager();
    
    // Envia e-mails
    $resultados = $email_manager->enviar_emails_lote($segundos);
    
    debugging('Resultados do envio: ' . print_r($resultados, true), DEBUG_DEVELOPER);
    
    // Retorna resultados
    echo json_encode([
        'status' => 'success',
        'data' => $resultados,
        'message' => 'Processo concluído'
    ]);
    
} catch (Exception $e) {
    debugging('Erro no envio: ' . $e->getMessage(), DEBUG_DEVELOPER);
    
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
} 