<?php
require_once('../../config.php');
require_login();
require_capability('local/monitorevasao:view', context_system::instance());

// Configura a página
$PAGE->set_url(new moodle_url('/local/monitorevasao/teste_email.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Teste de E-mail - Monitor de Evasão');
$PAGE->set_heading('Teste de E-mail - Monitor de Evasão');

// Início da página
echo $OUTPUT->header();

// Formulário de teste
if (isset($_POST['testar'])) {
    // Ativa debug
    debugging('Iniciando teste de e-mail', DEBUG_DEVELOPER);
    
    echo '<div class="alert alert-info">Iniciando teste de envio...</div>';
    
    // Configurações SMTP atuais
    echo "<div class='card mb-4'>
            <div class='card-header'>
                <h3 class='card-title'>Configurações SMTP Atuais</h3>
            </div>
            <div class='card-body'>
                <pre>";
    echo "SMTP Host: " . (!empty($CFG->smtphosts) ? $CFG->smtphosts : 'Não configurado') . "\n";
    echo "SMTP Secure: " . (!empty($CFG->smtpsecure) ? $CFG->smtpsecure : 'Não configurado') . "\n";
    echo "SMTP Auth: " . (!empty($CFG->smtpuser) ? 'Sim' : 'Não') . "\n";
    echo "No-reply: " . (!empty($CFG->noreplyaddress) ? $CFG->noreplyaddress : 'Não configurado') . "\n";
    echo "</pre>
            </div>
        </div>";

    // Testa envio
    try {
        $teste_user = new stdClass();
        $teste_user->id = $USER->id; // Usa o ID do usuário atual
        $teste_user->firstname = $USER->firstname;
        $teste_user->lastname = $USER->lastname;
        $teste_user->email = $_POST['email_teste'];
        $teste_user->lastaccess = time() - 3600;

        $email_manager = new \local_monitorevasao\email_manager();
        $resultado = $email_manager->enviar_email_inatividade($teste_user);

        if ($resultado) {
            echo "<div class='alert alert-success'>
                    <h4>Sucesso!</h4>
                    <p>E-mail enviado com sucesso para: {$_POST['email_teste']}</p>
                  </div>";
        } else {
            echo "<div class='alert alert-danger'>
                    <h4>Falha!</h4>
                    <p>Não foi possível enviar o e-mail. Verifique os logs do sistema.</p>
                  </div>";
        }
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>
                <h4>Erro!</h4>
                <p>Exceção: " . $e->getMessage() . "</p>
              </div>";
    }
}

// Formulário de teste
?>
<div class="card">
    <div class="card-body">
        <h3>Teste de Envio de E-mail</h3>
        <form method="post" class="mt-3">
            <div class="form-group">
                <label for="email_teste">E-mail para teste:</label>
                <input type="email" 
                       class="form-control" 
                       id="email_teste" 
                       name="email_teste" 
                       value="<?php echo $USER->email; ?>" 
                       required>
                <small class="form-text text-muted">
                    Use um e-mail válido para testar o envio.
                </small>
            </div>
            <button type="submit" 
                    name="testar" 
                    class="btn btn-primary mt-3">
                <i class="fa fa-envelope"></i> 
                Enviar E-mail de Teste
            </button>
        </form>
    </div>
</div>

<?php
// Fim da página
echo $OUTPUT->footer(); 