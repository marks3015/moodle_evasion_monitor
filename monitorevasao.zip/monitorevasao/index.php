<?php
require_once('../../config.php');
require_login();

// Verifica permissões
$context = context_system::instance();
require_capability('local/monitorevasao:view', $context);

// Configuração da página
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/monitorevasao/index.php'));
$PAGE->set_title(get_string('pluginname', 'local_monitorevasao'));
$PAGE->set_heading(get_string('monitorevasao', 'local_monitorevasao'));

// Obtém dados
$observer = new \local_monitorevasao\observer();
$usuarios_inativos = $observer->verificar_ultimo_acesso();

// Busca últimos e-mails enviados
$emails_enviados = $DB->get_records('local_monitorevasao_emails', 
    null, 'timecreated DESC', '*', 0, 10);

echo $OUTPUT->header();
?>

<div class="monitorevasao-dashboard">
    <h3><?php echo get_string('monitorevasao', 'local_monitorevasao'); ?></h3>

    <!-- Resumo -->
    <div class="dashboard-summary">
        <div class="card">
            <h4><?php echo get_string('totalinativos', 'local_monitorevasao'); ?></h4>
            <div class="number"><?php echo count($usuarios_inativos); ?></div>
        </div>
    </div>

    <!-- Tabela de usuários -->
    <table class="table">
        <thead>
            <tr>
                <th><?php echo get_string('nome', 'local_monitorevasao'); ?></th>
                <th><?php echo get_string('ultimoacesso', 'local_monitorevasao'); ?></th>
                <th><?php echo get_string('diasinativo', 'local_monitorevasao'); ?></th>
                <th><?php echo get_string('acoes', 'local_monitorevasao'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios_inativos as $usuario): ?>
            <tr>
                <td><?php echo fullname($usuario); ?></td>
                <td><?php echo userdate($usuario->lastaccess); ?></td>
                <td><?php echo floor((time() - $usuario->lastaccess) / (24*60*60)); ?></td>
                <td>
                    <a href="<?php echo new moodle_url('/user/profile.php', ['id' => $usuario->id]); ?>"
                        class="btn btn-secondary"><?php echo get_string('verperfil', 'local_monitorevasao'); ?></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="<?php echo new moodle_url('/local/monitorevasao/export.php', ['dias' => $dias]); ?>"
        class="btn btn-success mb-3">
        <?php echo get_string('exportar_dados', 'local_monitorevasao'); ?>
    </a>

    <a href="logs.php" class="btn btn-info ml-2">
        <i class="fa fa-list"></i> <?php echo get_string('ver_logs', 'local_monitorevasao'); ?>
    </a>

    <div class="mt-3">
        <button class="btn btn-primary" id="btnEnviarEmails" data-segundos="10">
            <i class="fa fa-envelope"></i>
            <?php echo get_string('enviar_emails', 'local_monitorevasao'); ?>
        </button>
        <div id="emailStatus" class="mt-2"></div>
    </div>
</div>

<script>
document.getElementById('btnEnviarEmails').addEventListener('click', async function() {
    if (!confirm('<?php echo get_string('confirmar_envio', 'local_monitorevasao'); ?>')) {
        return;
    }

    const btn = this;
    const status = document.getElementById('emailStatus');

    try {
        btn.disabled = true;
        btn.innerHTML =
            '<i class="fa fa-spinner fa-spin"></i> <?php echo get_string('enviando', 'local_monitorevasao'); ?>';
        status.innerHTML =
            '<div class="alert alert-info"><?php echo get_string('processando_envio', 'local_monitorevasao'); ?></div>';

        const response = await fetch('enviar_emails.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                segundos: parseInt(btn.dataset.segundos)
            })
        });

        const data = await response.json();
        console.log('Resposta:', data); // Debug

        if (data.status === 'success') {
            let mensagem = `
                <div class="alert alert-${data.data.enviados > 0 ? 'success' : 'warning'}">
                    <h4><?php echo get_string('resultado_envio', 'local_monitorevasao'); ?></h4>
                    <ul>
                        <li><?php echo get_string('total_usuarios', 'local_monitorevasao'); ?>: ${data.data.total}</li>
                        <li><?php echo get_string('emails_enviados', 'local_monitorevasao'); ?>: ${data.data.enviados}</li>
                        <li><?php echo get_string('falhas', 'local_monitorevasao'); ?>: ${data.data.falhas}</li>
                    </ul>
                    ${data.data.falhas > 0 ? '<p><?php echo get_string('ver_logs_detalhes', 'local_monitorevasao'); ?></p>' : ''}
                </div>`;
            status.innerHTML = mensagem;
        } else {
            throw new Error(data.message ||
                '<?php echo get_string('erro_envio', 'local_monitorevasao'); ?>');
        }
    } catch (error) {
        console.error('Erro:', error);
        status.innerHTML = `
            <div class="alert alert-danger">
                <h4><?php echo get_string('erro_envio', 'local_monitorevasao'); ?></h4>
                <p>${error.message}</p>
                <p><?php echo get_string('verificar_smtp', 'local_monitorevasao'); ?></p>
            </div>`;
    } finally {
        btn.disabled = false;
        btn.innerHTML =
            '<i class="fa fa-envelope"></i> <?php echo get_string('enviar_emails', 'local_monitorevasao'); ?>';
    }
});
</script>

<?php
echo $OUTPUT->footer();