<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version = 2025040007;
$plugin->requires = 2022112800; // Moodle 4.1
$plugin->component = 'local_monitorevasao';
$plugin->maturity = MATURITY_STABLE;
$plugin->release = 'v1.1.1';

// Dependências
/* 
$plugin->dependencies = [
    'core_message' => ANY_VERSION
];
*/ 