# Monitor de Evasão v1.1.0 (2025030100)

## Informações da Versão
- Versão: 2025030100
- Data: 01/03/2025
- Compatibilidade: Moodle 4.1+

## Novas Funcionalidades
- Sistema de e-mails para usuários inativos
- Envio em lote
- Templates personalizáveis
- Registro de envios

## Requisitos
- Moodle 4.1+
- PHP 7.4+
- Permissões de administrador

## Instalação/Atualização
1. Faça backup do banco de dados
2. Substitua os arquivos antigos pelos novos
3. Acesse: Administração do site > Notificações
4. Confirme a atualização
5. Verifique as novas configurações

## Uso
1. Acesse o Monitor de Evasão
2. Use os filtros para identificar usuários
3. Envie e-mails individuais ou em lote
4. Acompanhe os envios no registro

## Configuração
1. Defina períodos de inatividade
2. Configure templates de e-mail
3. Ajuste permissões de usuários
4. Configure agendamentos (opcional) 