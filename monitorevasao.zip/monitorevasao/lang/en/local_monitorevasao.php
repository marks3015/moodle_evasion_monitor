<?php
$string['pluginname'] = 'Dropout Monitor Plugin';
$string['monitorevasao'] = 'Dropout Monitor';
$string['totalinativos'] = 'Total of Inactive Users';
$string['nome'] = 'Name';
$string['ultimoacesso'] = 'Last Access';
$string['diasinativo'] = 'Inactive Days';
$string['acoes'] = 'Actions';
$string['verperfil'] = 'View Profile';
$string['exportar_dados'] = 'Export Data';
$string['ver_logs'] = 'View Logs';
$string['enviar_emails'] = 'Send Emails to Inactive Users';
$string['confirmar_envio'] = 'Do you want to send emails to all inactive users?';
$string['enviando'] = 'Sending...';
$string['processando_envio'] = 'Processing email sending...';
$string['resultado_envio'] = 'Sending Results';
$string['total_usuarios'] = 'Total Users';
$string['emails_enviados'] = 'Emails Sent';
$string['falhas'] = 'Failures';
$string['ver_logs_detalhes'] = 'Check logs for more details.';
$string['erro_envio'] = 'Error sending emails';
$string['verificar_smtp'] = 'Check SMTP settings and system logs.';
$string['email_body'] = '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1177d1;">Hello {nome},</h2>
        
        <p>We noticed that you haven\'t accessed our platform since <strong>{ultimo_acesso}</strong>.</p>
        
        <p>We would like to know if you are facing any difficulties or if we can assist you in any way.</p>
        
        <div style="text-align: center; margin: 30px 0;">
            <a href="{login_url}" 
               style="background-color: #1177d1; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 4px;">
                Access {site_nome}
            </a>
        </div>
        
        <p>If you need help, don\'t hesitate to contact us.</p>
        
        <p>Best regards,<br>
        The {site_nome} Team</p>
    </div>';
$string['email_subject'] = 'We miss you on Moodle Dev';


