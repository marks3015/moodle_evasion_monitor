<?php
$string['pluginname'] = 'Plugin Monitor de evasão';
$string['monitorevasao'] = 'Monitoramento de Evasão';
$string['totalinativos'] = 'Total de Usuários Inativos';
$string['nome'] = 'Nome';
$string['ultimoacesso'] = 'Último Acesso';
$string['diasinativo'] = 'Dias Inativo';
$string['acoes'] = 'Ações';
$string['verperfil'] = 'Ver Perfil';
$string['exportar_dados'] = 'Exportar Dados';
$string['ver_logs'] = 'Ver Logs';
$string['enviar_emails'] = 'Enviar E-mails para Inativos';
$string['confirmar_envio'] = 'Deseja enviar e-mails para todos os usuários inativos?';
$string['enviando'] = 'Enviando...';
$string['processando_envio'] = 'Processando envio de e-mails...';
$string['resultado_envio'] = 'Resultado do Envio';
$string['total_usuarios'] = 'Total de usuários';
$string['emails_enviados'] = 'E-mails enviados';
$string['falhas'] = 'Falhas';
$string['ver_logs_detalhes'] = 'Verifique os logs para mais detalhes.';
$string['erro_envio'] = 'Erro no envio de e-mails';
$string['verificar_smtp'] = 'Verifique as configurações de SMTP e os logs do sistema.';
$string['email_body_7_dias'] = '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1177d1;">Olá {nome},</h2>
        
        <p>Notamos que você não acessa nossa plataforma desde <strong>{ultimo_acesso}</strong>.</p>
        
        <p>Gostaríamos de saber se está encontrando alguma dificuldade ou se podemos ajudar de alguma forma.</p>
        
        <div style="text-align: center; margin: 30px 0;">
            <a href="{login_url}" 
               style="background-color: #1177d1; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 4px;">
                Acessar {site_nome}
            </a>
        </div>
        
        <p>Se precisar de ajuda, não hesite em nos contatar.</p>
        
        <p>Atenciosamente,<br>
        Equipe {site_nome}</p>
    </div>';
$string['email_subject'] = 'Sentimos sua falta em Moodle Dev';
$string['task_send_emails'] = 'Enviar e-mails para usuários inativos';
$string['email_body_1_dia'] = '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1177d1;">Olá {nome},</h2>
        
        <p>Olá! Não esqueça de acessar a plataforma e realizar as suas atividades.</strong>.</p>
        
        <p>Se precisar de ajuda, não hesite em nos contatar.</p>
        
        <p>Atenciosamente,<br>
        Equipe {site_nome}</p>
    </div>';