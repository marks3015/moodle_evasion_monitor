<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_monitorevasao_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    if ($oldversion < 2025030100) {
        // Cria tabela para registro de e-mails
        $table = new xmldb_table('local_monitorevasao_emails');
        
        // Adiciona campos
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('status', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        
        // Adiciona chaves
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('userid', XMLDB_KEY_FOREIGN, ['userid'], 'user', ['id']);
        
        // Cria a tabela
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Atualiza para a nova versão
        upgrade_plugin_savepoint(true, 2025030100, 'local', 'monitorevasao');
    }

    return true;
} 