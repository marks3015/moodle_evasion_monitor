<?php
$string['pluginname'] = 'Monitor de Evasão';
$string['monitorevasao'] = 'Monitor de Evasão';
$string['monitorevasao:view'] = 'Visualizar Monitor de Evasão'; 